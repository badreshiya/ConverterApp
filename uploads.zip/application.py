import os
import json
import pandas as pd
from flask import Flask, request, render_template, send_file, jsonify
from dotenv import load_dotenv
import logging
from script import convert_json_to_excel

# Initialize logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Load environment variables
load_dotenv()

application = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'uploads'
CONVERTED_FOLDER = 'converted'
ALLOWED_EXTENSIONS = {'json'}
application.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
application.config['CONVERTED_FOLDER'] = CONVERTED_FOLDER

# Ensure upload and converted folders exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(CONVERTED_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@application.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@application.route('/upload', methods=['POST'])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    # Convert JSON to Excel
    try:
        df = pd.read_json(file_path)
        excel_path = os.path.join(CONVERTED_FOLDER, file.filename.replace(".json", ".xlsx"))

        # Ensure the file is not being used
        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            df.to_excel(writer, index=False)

        df = None  # ✅ Release memory to avoid access errors

        # Ensure file exists before deleting
        if os.path.exists(file_path):
            os.remove(file_path)  # ✅ Now safe to delete

        return jsonify({"file_path": f"/download/{os.path.basename(excel_path)}"})

    except Exception as e:
        return jsonify({"error": f"Conversion failed: {str(e)}"}), 500

@application.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    file_path = os.path.join(CONVERTED_FOLDER, filename)

    if not os.path.exists(file_path):
        logging.error(f"File not found: {file_path}")
        return jsonify({'error': 'File not found'}), 404

    response = send_file(file_path, as_attachment=True)
    os.remove(file_path)  
    return response

if __name__ == '__main__':
    application.run(debug=True)
